import { Client } from "@notionhq/client";

// Initialize Notion client
export const notion = new Client({
    auth: process.env.NOTION_INTEGRATION_SECRET!,
});

// Extract the page ID from the Notion page URL
function extractPageIdFromUrl(pageUrl: string): string {
    const match = pageUrl.match(/([a-f0-9]{32})(?:[?#]|$)/i);
    if (match && match[1]) {
        return match[1];
    }

    throw Error("Failed to extract page ID");
}

export const NOTION_PAGE_ID = process.env.NOTION_PAGE_URL ? extractPageIdFromUrl(process.env.NOTION_PAGE_URL) : null;

/**
 * Lists all child databases contained within NOTION_PAGE_ID
 * @returns {Promise<Array<{id: string, title: string}>>} - Array of database objects with id and title
 */
export async function getNotionDatabases() {
    if (!NOTION_PAGE_ID) return [];

    // Array to store the child databases
    const childDatabases = [];

    try {
        // Query all child blocks in the specified page
        let hasMore = true;
        let startCursor: string | undefined = undefined;

        while (hasMore) {
            const response = await notion.blocks.children.list({
                block_id: NOTION_PAGE_ID,
                start_cursor: startCursor,
            });

            // Process the results
            for (const block of response.results) {
                // Check if the block is a child database
                if (block.type === "child_database") {
                    const databaseId = block.id;

                    // Retrieve the database title
                    try {
                        const databaseInfo = await notion.databases.retrieve({
                            database_id: databaseId,
                        });

                        // Add the database to our list
                        childDatabases.push(databaseInfo);
                    } catch (error) {
                        console.error(`Error retrieving database ${databaseId}:`, error);
                    }
                }
            }

            // Check if there are more results to fetch
            hasMore = response.has_more;
            startCursor = response.next_cursor || undefined;
        }

        return childDatabases;
    } catch (error) {
        console.error("Error listing child databases:", error);
        throw error;
    }
}

// Find get a Notion database with the matching title
export async function findDatabaseByTitle(title: string) {
    const databases = await getNotionDatabases();

    for (const db of databases) {
        if (db.title && Array.isArray(db.title) && db.title.length > 0) {
            const dbTitle = db.title[0]?.plain_text?.toLowerCase() || "";
            if (dbTitle === title.toLowerCase()) {
                return db;
            }
        }
    }

    return null;
}

// Create a new database if one with a matching title does not exist
export async function createDatabaseIfNotExists(title: string, properties: any) {
    if (!NOTION_PAGE_ID) {
        throw new Error("NOTION_PAGE_URL environment variable is required");
    }

    const existingDb = await findDatabaseByTitle(title);
    if (existingDb) {
        return existingDb;
    }
    return await notion.databases.create({
        parent: {
            type: "page_id",
            page_id: NOTION_PAGE_ID
        },
        title: [
            {
                type: "text",
                text: {
                    content: title
                }
            }
        ],
        properties
    });
}

// Get all testimonials from the Notion database
export async function getTestimonials() {
    try {
        const testimonialsDb = await findDatabaseByTitle("Testimonials");
        if (!testimonialsDb) return [];

        const response = await notion.databases.query({
            database_id: testimonialsDb.id,
        });

        return response.results.map((page: any) => {
            const properties = page.properties;

            return {
                notionId: page.id,
                name: properties.Name?.title?.[0]?.plain_text || "Anonymous",
                location: properties.Location?.rich_text?.[0]?.plain_text || "",
                review: properties.Review?.rich_text?.[0]?.plain_text || "",
                rating: properties.Rating?.number || 5,
                isActive: properties.Active?.checkbox !== false,
            };
        });
    } catch (error) {
        console.error("Error fetching testimonials from Notion:", error);
        return [];
    }
}

// Get all pricing plans from the Notion database
export async function getPricingPlans() {
    try {
        const plansDb = await findDatabaseByTitle("Pricing Plans");
        if (!plansDb) return [];

        const response = await notion.databases.query({
            database_id: plansDb.id,
        });

        return response.results.map((page: any) => {
            const properties = page.properties;

            return {
                notionId: page.id,
                name: properties.Name?.title?.[0]?.plain_text || "Plan",
                price: properties.Price?.rich_text?.[0]?.plain_text || "£0",
                period: properties.Period?.rich_text?.[0]?.plain_text || "month",
                savings: properties.Savings?.rich_text?.[0]?.plain_text || null,
                popular: properties.Popular?.checkbox || false,
                planId: properties.PlanId?.rich_text?.[0]?.plain_text || "plan",
                isActive: properties.Active?.checkbox !== false,
            };
        });
    } catch (error) {
        console.error("Error fetching pricing plans from Notion:", error);
        return [];
    }
}

// Get FAQ items from the Notion database
export async function getFAQItems() {
    try {
        const faqDb = await findDatabaseByTitle("FAQ");
        if (!faqDb) return [];

        const response = await notion.databases.query({
            database_id: faqDb.id,
        });

        return response.results.map((page: any) => {
            const properties = page.properties;

            return {
                notionId: page.id,
                question: properties.Question?.title?.[0]?.plain_text || "",
                answer: properties.Answer?.rich_text?.[0]?.plain_text || "",
                order: properties.Order?.number || 0,
                isActive: properties.Active?.checkbox !== false,
            };
        }).sort((a, b) => a.order - b.order);
    } catch (error) {
        console.error("Error fetching FAQ items from Notion:", error);
        return [];
    }
}